package ee.ut.sci.potisepp;

import java.io.IOException;
import java.util.*;

import org.apache.commons.math3.analysis.function.Gaussian;
import org.apache.commons.math3.analysis.function.Gaussian.Parametric;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;

public class HadoopTest {
	
	public static class MyMap extends MapReduceBase implements Mapper<Text, BytesWritable, Text, BytesWritable>{
		
		public void map(Text key, BytesWritable value, OutputCollector<Text, BytesWritable> output, Reporter reporter) throws IOException
		{	
			
			//extract height & width from the key
			String[] parts = key.toString().split(";");
			int widthInPx = Integer.valueOf(parts[1]);
			int heightInPx = Integer.valueOf(parts[2]);
			int numPixels = widthInPx*heightInPx;
			
			float[][] R = new float[widthInPx][heightInPx];
			float[][] G = new float[widthInPx][heightInPx];
			float[][] B = new float[widthInPx][heightInPx];
			
			//initialize all to 0
			for(int x = 0; x < widthInPx; x++){
				for(int y = 0; y < heightInPx; y++){
					R[x][y]	= 0;
					G[x][y]	= 0;
					B[x][y]	= 0;
				}
			}
			
			//radius of the kernel
			int kernelSize = 4;
			int tmp_x, tmp_y;
			double w, d;
			
			//define a gaussian function
			double[] gParams = { 1/((2*kernelSize+1)*Math.sqrt(2*Math.PI)), 0.0, 2*kernelSize+1 };
			Parametric g = new Gaussian.Parametric();
		
			float R_w, G_w, B_w;
			
			byte[] result = new byte[widthInPx * heightInPx * 3];
			
			byte[] pixels = value.getBytes();
			
			float I_p, I_q;
			
			//for each pixel p in S
			for(int x = 0; x < widthInPx; x++){
				for(int y = 0; y < heightInPx; y++){
					
					R_w = 0.0f;
					G_w = 0.0f;
					B_w = 0.0f;					
					
					//for each pixel q in the kernelSize-neighborhood of p in S
					for(int kx = 0; kx < 2*kernelSize + 1; kx++){
						
						tmp_x = x - kernelSize + kx;
						if (tmp_x < 0) tmp_x = 0;
						else if (tmp_x > widthInPx - 1) tmp_x = widthInPx - 1;
						
						for(int ky = 0; ky < 2*kernelSize + 1; ky++){
							
							tmp_y = y - kernelSize + ky;
							if (tmp_y < 0) tmp_y = 0;
							else if (tmp_y > heightInPx - 1) tmp_y = heightInPx - 1; 
							
							d = g.value(dist(tmp_x, tmp_y, x, y), gParams);
							
							//red
							I_p = ((int) pixels[x + y*widthInPx] & 0xff) / 255.0f;
							I_q = ((int) pixels[tmp_x + tmp_y*widthInPx] & 0xff) / 255.0f;
							w = d * g.value(I_p - I_q, gParams); 
							R[x][y] += w*I_q;
							R_w += w;
							
							//green
							I_p = ((int) pixels[x + y*widthInPx + numPixels] & 0xff) / 255.0f;
							I_q = ((int) pixels[tmp_x + tmp_y*widthInPx + numPixels] & 0xff) / 255.0f;
							w = d * g.value(I_p - I_q, gParams); 
							G[x][y] += w*I_q;
							G_w += w;
							
							//blue
							I_p = ((int) pixels[x + y*widthInPx + 2*numPixels] & 0xff) / 255.0f;
							I_q = ((int) pixels[tmp_x + tmp_y*widthInPx + 2*numPixels] & 0xff) / 255.0f;
							w = d * g.value(I_p - I_q, gParams);
							B[x][y] += w*I_q;
							B_w += w;
							
						}
					}
					
					//normalization
					R[x][y] = R[x][y] / R_w;
					G[x][y] = G[x][y] / G_w;
					B[x][y] = B[x][y] / B_w;
					
					//write to result
					result[x + y*widthInPx] = (byte) (R[x][y] * 255.0f);
					result[x + y*widthInPx + numPixels] = (byte) (G[x][y] * 255.0f);
					result[x + y*widthInPx + 2*numPixels] = (byte) (B[x][y] * 255.0f);
				}				
			}
			
			System.out.println(parts[0]+" "+widthInPx+" "+heightInPx+ " " + value.getLength());
			
			output.collect(key, new BytesWritable(result));
		}
		
		//Manhattan distance
		public double dist(int x1, int y1, int x2, int y2){
			
			//euclidean
			//return Math.abs( Math.sqrt( Math.pow(x2-x1, 2) + Math.pow(y2-y1, 2) ) );
			
			return Math.abs(x2-x1)+Math.abs(y2-y1);
			
		}
	}
	
	public static class MyReduce extends MapReduceBase implements Reducer<Text, BytesWritable, Text, BytesWritable>{		
		public void reduce(Text key, Iterator<BytesWritable> values, OutputCollector<Text, BytesWritable> output, Reporter reporter) throws IOException
		{
			while(values.hasNext()){
				output.collect(key, values.next());
			}
		}		
	}

	public static void main(String[] args) throws Exception {
		
//		if(args.length!=2){
//			System.out.println("Not enough arguments! Please provide input path and output path.");
//			System.exit(0);
//		}					
				
		JobConf conf = new JobConf(HadoopTest.class);
		conf.setJobName("hadoop_fast_bf");
		
		conf.setOutputKeyClass(Text.class);
		conf.setOutputValueClass(BytesWritable.class);
		
		conf.setMapperClass(MyMap.class);
		conf.setReducerClass(MyReduce.class);
		
		conf.setInputFormat(MyInputFormat.class);
		conf.setOutputFormat(MyOutputFormat.class);
		
		FileInputFormat.setInputPaths(conf, new Path("/home/karl/kool/msc_thesis/big_img/mapreduce_in"));
		FileOutputFormat.setOutputPath(conf, new Path("/home/karl/kool/msc_thesis/big_img/mapreduce_out"));
		
//		FileInputFormat.setInputPaths(conf, new Path("/Users/karl/kool/msc_thesis/mapreduce_in"));
//		FileOutputFormat.setOutputPath(conf, new Path("/Users/karl/kool/msc_thesis/mapreduce_out"));
		
		JobClient.runJob(conf);
		
	}
	
}
